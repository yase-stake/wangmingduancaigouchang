module.exports = {
    model: {
        uid: "",
        goodsid:"",
        num:"",
        status:""
    },
    check: dataArr => dataArr // 不处理, 只为了不报错
}